package persistence;

import model.Mensagem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Usa um banco H2 em memoria (sem rede e sem arquivos), um novo para cada teste. */
class MensagemRepositoryTest {

    private MensagemRepository repository;

    @BeforeEach
    void prepararBancoLimpo() throws SQLException {
        String url = "jdbc:h2:mem:" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1";
        repository = new MensagemRepository(url, "sa", "");
        repository.criarTabelaSeNecessario();
    }

    @Test
    void bancoVazioDeveDevolverListaVazia() throws SQLException {
        assertTrue(repository.buscarUltimas(10).isEmpty());
    }

    @Test
    void deveSalvarERecuperarMensagemComTodosOsCampos() throws SQLException {
        LocalDateTime horario = LocalDateTime.of(2026, 10, 28, 9, 30, 15);
        repository.salvar(new Mensagem("Ana", "oi", horario));

        List<Mensagem> lidas = repository.buscarUltimas(10);

        assertEquals(1, lidas.size());
        assertEquals("Ana", lidas.get(0).getRemetente());
        assertEquals("oi", lidas.get(0).getConteudo());
        assertEquals(horario, lidas.get(0).getHorario());
    }

    @Test
    void buscarUltimasDeveRespeitarOLimiteEDevolverEmOrdemCronologica() throws SQLException {
        LocalDateTime base = LocalDateTime.of(2026, 10, 28, 12, 0, 0);
        for (int i = 1; i <= 5; i++) {
            repository.salvar(new Mensagem("Ana", "msg" + i, base.plusSeconds(i)));
        }

        List<Mensagem> ultimas = repository.buscarUltimas(3);

        assertEquals(3, ultimas.size());
        assertEquals("msg3", ultimas.get(0).getConteudo());
        assertEquals("msg5", ultimas.get(2).getConteudo());
    }
}
