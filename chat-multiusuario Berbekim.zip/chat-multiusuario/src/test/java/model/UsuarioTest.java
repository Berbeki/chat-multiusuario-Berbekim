package model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UsuarioTest {

    @Test
    void deveAceitarNomesValidos() {
        assertTrue(Usuario.nomeValido("Ana"));
        assertTrue(Usuario.nomeValido("joao_2026"));
        assertTrue(Usuario.nomeValido("José"));
    }

    @Test
    void deveRejeitarNomesInvalidos() {
        assertFalse(Usuario.nomeValido(null));
        assertFalse(Usuario.nomeValido("   "));
        assertFalse(Usuario.nomeValido("ana maria"));
        assertFalse(Usuario.nomeValido("a".repeat(Usuario.TAMANHO_MAXIMO_NOME + 1)));
    }

    @Test
    void construtorDeveLancarExcecaoParaNomeInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("ana maria"));
    }

    @Test
    void usuariosComMesmoNomeIgnorandoMaiusculasDevemSerIguais() {
        assertEquals(new Usuario("Ana"), new Usuario("ANA"));
    }
}
