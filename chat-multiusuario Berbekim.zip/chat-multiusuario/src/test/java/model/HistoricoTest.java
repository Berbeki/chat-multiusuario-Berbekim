package model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HistoricoTest {

    @Test
    void limiteInvalidoDeveVirarOPadrao() {
        assertEquals(Historico.LIMITE_PADRAO, Historico.normalizarLimite(0));
        assertEquals(Historico.LIMITE_PADRAO, Historico.normalizarLimite(-5));
    }

    @Test
    void limiteAcimaDoMaximoDeveSerReduzido() {
        assertEquals(Historico.LIMITE_MAXIMO, Historico.normalizarLimite(10_000));
    }

    @Test
    void limiteValidoDeveSerMantido() {
        assertEquals(30, Historico.normalizarLimite(30));
    }

    @Test
    void formatarDeveManterAOrdemDasMensagens() {
        LocalDateTime t = LocalDateTime.of(2026, 10, 28, 10, 0, 0);
        List<Mensagem> msgs = List.of(
                new Mensagem("Ana", "primeira", t),
                new Mensagem("Bob", "segunda", t.plusSeconds(5)));

        List<String> linhas = Historico.formatar(msgs);

        assertEquals(List.of("[10:00:00] Ana: primeira", "[10:00:05] Bob: segunda"), linhas);
    }
}
