package model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MensagemTest {

    @Test
    void formatarDeveSeguirOPadraoHoraRemetenteConteudo() {
        Mensagem m = new Mensagem("Ana", "ola", LocalDateTime.of(2026, 10, 28, 14, 5, 9));
        assertEquals("[14:05:09] Ana: ola", m.formatar());
    }

    @Test
    void deveRemoverEspacosExtrasDoConteudoEDoRemetente() {
        Mensagem m = new Mensagem("  Bob ", "  tudo bem?  ", LocalDateTime.of(2026, 1, 1, 0, 0, 0));
        assertEquals("Bob", m.getRemetente());
        assertEquals("tudo bem?", m.getConteudo());
    }

    @Test
    void deveRejeitarConteudoVazio() {
        assertThrows(IllegalArgumentException.class, () -> new Mensagem("Ana", "   "));
    }

    @Test
    void deveRejeitarRemetenteNulo() {
        assertThrows(IllegalArgumentException.class, () -> new Mensagem(null, "oi"));
    }

    @Test
    void deveRejeitarConteudoMaiorQueOLimite() {
        String grande = "x".repeat(Mensagem.TAMANHO_MAXIMO_CONTEUDO + 1);
        assertThrows(IllegalArgumentException.class, () -> new Mensagem("Ana", grande));
    }
}
