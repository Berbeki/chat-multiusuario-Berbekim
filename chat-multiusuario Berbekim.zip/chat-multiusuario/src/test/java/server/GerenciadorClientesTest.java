package server;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Testa broadcast e sincronizacao com "clientes falsos": nenhuma rede envolvida. */
class GerenciadorClientesTest {

    /** Destinatario falso que apenas guarda o que recebe. */
    static class ClienteFalso implements Destinatario {
        private final String nome;
        private final boolean falha;
        final List<String> recebidas = Collections.synchronizedList(new ArrayList<>());

        ClienteFalso(String nome) {
            this(nome, false);
        }

        ClienteFalso(String nome, boolean falha) {
            this.nome = nome;
            this.falha = falha;
        }

        @Override
        public String getNome() {
            return nome;
        }

        @Override
        public boolean enviar(String texto) {
            if (falha) {
                return false;
            }
            recebidas.add(texto);
            return true;
        }
    }

    @Test
    void broadcastDeveChegarATodosOsClientes() {
        GerenciadorClientes g = new GerenciadorClientes();
        ClienteFalso a = new ClienteFalso("Ana");
        ClienteFalso b = new ClienteFalso("Bob");
        g.adicionar(a);
        g.adicionar(b);

        g.broadcast("ola");

        assertEquals(List.of("ola"), a.recebidas);
        assertEquals(List.of("ola"), b.recebidas);
    }

    @Test
    void naoDevePermitirNomeRepetidoIgnorandoMaiusculas() {
        GerenciadorClientes g = new GerenciadorClientes();
        assertTrue(g.adicionar(new ClienteFalso("Ana")));
        assertFalse(g.adicionar(new ClienteFalso("ANA")));
        assertEquals(1, g.quantidade());
    }

    @Test
    void clienteRemovidoNaoDeveReceberMaisMensagens() {
        GerenciadorClientes g = new GerenciadorClientes();
        ClienteFalso a = new ClienteFalso("Ana");
        ClienteFalso b = new ClienteFalso("Bob");
        g.adicionar(a);
        g.adicionar(b);

        g.remover(b);
        g.broadcast("so a Ana");

        assertEquals(1, a.recebidas.size());
        assertTrue(b.recebidas.isEmpty());
    }

    @Test
    void clienteQueFalhaNoEnvioDeveSerRemovidoSemAfetarOsDemais() {
        GerenciadorClientes g = new GerenciadorClientes();
        ClienteFalso quebrado = new ClienteFalso("Caido", true);
        ClienteFalso ok = new ClienteFalso("Ana");
        g.adicionar(quebrado);
        g.adicionar(ok);

        g.broadcast("teste");

        assertEquals(List.of("teste"), ok.recebidas);
        assertFalse(g.contem("Caido"));
        assertEquals(1, g.quantidade());
    }

    @Test
    void duasThreadsTentandoOMesmoNomeSoUmaDeveConseguir() throws Exception {
        // Race condition: sem synchronized, as duas poderiam passar na verificacao ao mesmo tempo.
        for (int rodada = 0; rodada < 200; rodada++) {
            GerenciadorClientes g = new GerenciadorClientes();
            AtomicInteger sucessos = new AtomicInteger();
            CountDownLatch largada = new CountDownLatch(1);
            ExecutorService pool = Executors.newFixedThreadPool(2);
            for (int i = 0; i < 2; i++) {
                pool.submit(() -> {
                    try {
                        largada.await();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    if (g.adicionar(new ClienteFalso("Mesmo"))) {
                        sucessos.incrementAndGet();
                    }
                });
            }
            largada.countDown();
            pool.shutdown();
            pool.awaitTermination(5, TimeUnit.SECONDS);

            assertEquals(1, sucessos.get());
            assertEquals(1, g.quantidade());
        }
    }

    @Test
    void broadcastsConcorrentesNaoDevemPerderMensagens() throws Exception {
        GerenciadorClientes g = new GerenciadorClientes();
        ClienteFalso a = new ClienteFalso("Ana");
        ClienteFalso b = new ClienteFalso("Bob");
        g.adicionar(a);
        g.adicionar(b);

        int threads = 8;
        int porThread = 250;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        for (int t = 0; t < threads; t++) {
            final int id = t;
            pool.submit(() -> {
                for (int i = 0; i < porThread; i++) {
                    g.broadcast("t" + id + "-" + i);
                }
            });
        }
        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);

        assertEquals(threads * porThread, a.recebidas.size());
        assertEquals(threads * porThread, b.recebidas.size());
        // todos veem as mensagens exatamente na mesma ordem
        assertEquals(a.recebidas, b.recebidas);
    }
}
