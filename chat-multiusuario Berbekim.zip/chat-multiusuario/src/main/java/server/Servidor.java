package server;

import persistence.MensagemRepository;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

/**
 * Servidor do chat: escuta numa porta e cria uma thread (ClienteHandler) por conexao.
 */
public class Servidor {

    public static final int PORTA_PADRAO = 5000;
    public static final int TAMANHO_HISTORICO = 20;

    private final int porta;
    private final MensagemRepository repository;
    private final GerenciadorClientes clientes = new GerenciadorClientes();

    public Servidor(int porta, MensagemRepository repository) {
        this.porta = porta;
        this.repository = repository;
    }

    public GerenciadorClientes getClientes() {
        return clientes;
    }

    public MensagemRepository getRepository() {
        return repository;
    }

    public void iniciar() throws IOException, SQLException {
        repository.criarTabelaSeNecessario();

        try (ServerSocket serverSocket = new ServerSocket(porta)) {
            System.out.println("[Servidor] Chat no ar na porta " + porta + ". Aguardando clientes...");
            int contador = 0;
            while (true) {
                Socket socket = serverSocket.accept(); // bloqueia ate chegar um cliente
                contador++;
                System.out.println("[Servidor] Nova conexao: " + socket.getRemoteSocketAddress());
                Thread thread = new Thread(new ClienteHandler(socket, this), "cliente-" + contador);
                thread.start(); // o laco volta ao accept() imediatamente
            }
        }
    }

    public static void main(String[] args) {
        int porta = PORTA_PADRAO;
        if (args.length > 0) {
            porta = Integer.parseInt(args[0]);
        }
        try {
            new Servidor(porta, MensagemRepository.padrao()).iniciar();
        } catch (IOException | SQLException e) {
            System.err.println("[Servidor] Falha ao iniciar: " + e.getMessage());
        }
    }
}
