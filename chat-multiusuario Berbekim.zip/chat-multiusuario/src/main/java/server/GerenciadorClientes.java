package server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Guarda a lista de clientes conectados, que e o recurso COMPARTILHADO por todas as threads.
 *
 * Toda leitura/escrita passa por um bloco synchronized sobre a propria lista
 * (a mesma trava usada internamente por Collections.synchronizedList), garantindo:
 *  - nome unico: verificar "ja existe?" e adicionar sao uma operacao atomica;
 *  - broadcast consistente: todos os clientes recebem as mensagens na mesma ordem;
 *  - iteracao segura: ninguem entra ou sai da lista no meio do broadcast.
 */
public class GerenciadorClientes {

    private final List<Destinatario> clientes = Collections.synchronizedList(new ArrayList<>());

    /** Adiciona o cliente se o nome ainda nao estiver em uso (sem diferenciar maiusculas). */
    public boolean adicionar(Destinatario novo) {
        synchronized (clientes) {
            for (Destinatario c : clientes) {
                if (c.getNome().equalsIgnoreCase(novo.getNome())) {
                    return false;
                }
            }
            clientes.add(novo);
            return true;
        }
    }

    public void remover(Destinatario cliente) {
        clientes.remove(cliente); // metodo ja sincronizado pela synchronizedList
    }

    /**
     * Envia o texto a todos os clientes conectados.
     * Quem falhar na entrega (desconexao abrupta) e removido, sem afetar os demais.
     */
    public void broadcast(String texto) {
        synchronized (clientes) {
            List<Destinatario> falharam = new ArrayList<>();
            for (Destinatario c : clientes) {
                if (!c.enviar(texto)) {
                    falharam.add(c);
                }
            }
            clientes.removeAll(falharam);
        }
    }

    public int quantidade() {
        return clientes.size();
    }

    public boolean contem(String nome) {
        synchronized (clientes) {
            for (Destinatario c : clientes) {
                if (c.getNome().equalsIgnoreCase(nome)) {
                    return true;
                }
            }
            return false;
        }
    }
}
