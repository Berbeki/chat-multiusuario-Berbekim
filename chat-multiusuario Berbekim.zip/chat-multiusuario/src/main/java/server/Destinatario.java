package server;

/**
 * Qualquer coisa que possa receber texto do servidor (na pratica, um ClienteHandler).
 * Esta interface permite testar o broadcast com "clientes falsos", sem rede real.
 */
public interface Destinatario {

    String getNome();

    /** Envia uma linha de texto. Devolve false se a entrega falhou (cliente caiu). */
    boolean enviar(String texto);
}
