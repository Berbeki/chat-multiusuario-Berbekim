package server;

import model.Historico;
import model.Mensagem;
import model.Usuario;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

/**
 * Atende UM cliente, em uma thread propria.
 * Le linhas do socket e repassa ao Servidor/GerenciadorClientes para o broadcast.
 */
public class ClienteHandler implements Runnable, Destinatario {

    private final Socket socket;
    private final Servidor servidor;

    private BufferedReader entrada;
    private PrintWriter saida;
    private volatile String nome; // lido por outras threads durante o broadcast

    public ClienteHandler(Socket socket, Servidor servidor) {
        this.socket = socket;
        this.servidor = servidor;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public boolean enviar(String texto) {
        saida.println(texto); // PrintWriter e thread-safe nos metodos println
        return !saida.checkError();
    }

    @Override
    public void run() {
        boolean registrado = false;
        try {
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            saida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

            registrado = registrarUsuario();
            if (!registrado) {
                return;
            }

            enviarHistorico();
            servidor.getClientes().broadcast("*** " + nome + " entrou no chat ***");
            lerMensagens();

        } catch (IOException e) {
            // desconexao abrupta do cliente: so registramos e seguimos (nao derruba o servidor)
            String quem = (nome != null) ? nome : "cliente nao identificado";
            System.out.println("[Servidor] Conexao perdida com " + quem);
        } finally {
            if (registrado) {
                servidor.getClientes().remover(this);
                servidor.getClientes().broadcast("*** " + nome + " saiu do chat ***");
            }
            fecharSocket();
        }
    }

    /** Pede o nome ate receber um valido e ainda nao usado. Devolve false se o cliente sair antes. */
    private boolean registrarUsuario() throws IOException {
        while (true) {
            saida.println("Digite seu nome (letras, numeros ou _, ate " + Usuario.TAMANHO_MAXIMO_NOME + "):");
            String candidato = entrada.readLine();
            if (candidato == null) {
                return false;
            }
            if (!Usuario.nomeValido(candidato)) {
                saida.println("Nome invalido. Tente novamente.");
                continue;
            }
            nome = new Usuario(candidato).getNome();
            if (servidor.getClientes().adicionar(this)) {
                saida.println("Bem-vindo(a), " + nome + "! Digite /sair para desconectar.");
                return true;
            }
            nome = null;
            saida.println("Esse nome ja esta em uso. Escolha outro.");
        }
    }

    private void enviarHistorico() {
        try {
            int limite = Historico.normalizarLimite(Servidor.TAMANHO_HISTORICO);
            var ultimas = servidor.getRepository().buscarUltimas(limite);
            if (!ultimas.isEmpty()) {
                saida.println("--- ultimas mensagens ---");
                for (String linha : Historico.formatar(ultimas)) {
                    saida.println(linha);
                }
                saida.println("--- fim do historico ---");
            }
        } catch (SQLException e) {
            saida.println("(nao foi possivel carregar o historico)");
            System.err.println("[Servidor] Erro ao buscar historico: " + e.getMessage());
        }
    }

    private void lerMensagens() throws IOException {
        String linha;
        while ((linha = entrada.readLine()) != null) {
            linha = linha.trim();
            if (linha.equalsIgnoreCase("/sair")) {
                break;
            }
            if (linha.isEmpty()) {
                continue;
            }
            if (linha.length() > Mensagem.TAMANHO_MAXIMO_CONTEUDO) {
                linha = linha.substring(0, Mensagem.TAMANHO_MAXIMO_CONTEUDO);
            }

            Mensagem mensagem = new Mensagem(nome, linha);
            try {
                servidor.getRepository().salvar(mensagem); // 1) persiste
            } catch (SQLException e) {
                saida.println("(aviso: sua mensagem nao foi salva no historico)");
                System.err.println("[Servidor] Erro ao salvar mensagem: " + e.getMessage());
            }
            servidor.getClientes().broadcast(mensagem.formatar()); // 2) distribui
        }
    }

    private void fecharSocket() {
        try {
            socket.close();
        } catch (IOException ignorado) {
            // nada a fazer
        }
    }
}
