package persistence;

import model.Mensagem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Repository/DAO: unico ponto do sistema que fala SQL.
 *
 * Cada operacao abre e fecha a propria Connection (try-with-resources).
 * Assim varias threads podem usar o repository ao mesmo tempo sem dividir
 * uma Connection (que nao e thread-safe).
 */
public class MensagemRepository {

    private static final String SQL_CRIAR_TABELA =
            "CREATE TABLE IF NOT EXISTS mensagens ("
                    + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                    + "remetente VARCHAR(20) NOT NULL, "
                    + "conteudo VARCHAR(500) NOT NULL, "
                    + "horario TIMESTAMP NOT NULL)";

    private static final String SQL_INSERIR =
            "INSERT INTO mensagens (remetente, conteudo, horario) VALUES (?, ?, ?)";

    private static final String SQL_ULTIMAS =
            "SELECT remetente, conteudo, horario FROM mensagens ORDER BY id DESC LIMIT ?";

    private final String url;
    private final String usuario;
    private final String senha;

    public MensagemRepository(String url, String usuario, String senha) {
        this.url = url;
        this.usuario = usuario;
        this.senha = senha;
    }

    /** Banco em arquivo (pasta ./data), que sobrevive entre execucoes do servidor. */
    public static MensagemRepository padrao() {
        return new MensagemRepository("jdbc:h2:./data/chatdb", "sa", "");
    }

    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(url, usuario, senha);
    }

    public void criarTabelaSeNecessario() throws SQLException {
        try (Connection c = conectar(); Statement st = c.createStatement()) {
            st.execute(SQL_CRIAR_TABELA);
        }
    }

    public void salvar(Mensagem m) throws SQLException {
        try (Connection c = conectar(); PreparedStatement ps = c.prepareStatement(SQL_INSERIR)) {
            ps.setString(1, m.getRemetente());
            ps.setString(2, m.getConteudo());
            ps.setTimestamp(3, Timestamp.valueOf(m.getHorario()));
            ps.executeUpdate();
        }
    }

    /** Devolve as ultimas n mensagens em ordem cronologica (a mais antiga primeiro). */
    public List<Mensagem> buscarUltimas(int n) throws SQLException {
        List<Mensagem> resultado = new ArrayList<>();
        try (Connection c = conectar(); PreparedStatement ps = c.prepareStatement(SQL_ULTIMAS)) {
            ps.setInt(1, n);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    resultado.add(new Mensagem(
                            rs.getString("remetente"),
                            rs.getString("conteudo"),
                            rs.getTimestamp("horario").toLocalDateTime()));
                }
            }
        }
        Collections.reverse(resultado); // veio da mais nova para a mais antiga
        return resultado;
    }
}
