package client;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Janela do cliente do chat com interface grafica (Swing). Rode o main desta classe.
 *
 * Em Arquivo > Nova janela (Ctrl+N) abre-se outro cliente no mesmo programa,
 * o que facilita testar com 3 usuarios sem criar varias configuracoes de execucao.
 */
@SuppressWarnings({"serial", "this-escape"})
public class ClienteChatGUI extends JFrame {

    private final ClienteChatPainel painel;

    public ClienteChatGUI() {
        super("Chat Multiusuário");
        painel = new ClienteChatPainel(this::setTitle);

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setContentPane(painel);
        setJMenuBar(criarMenu());
        setSize(560, 560);
        setMinimumSize(new Dimension(420, 380));
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                painel.desconectar();
                dispose(); // quando a ultima janela fechar, o programa termina sozinho
            }
        });
    }

    private JMenuBar criarMenu() {
        JMenu arquivo = new JMenu("Arquivo");

        JMenuItem novaJanela = new JMenuItem("Nova janela (outro usuário)");
        novaJanela.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        novaJanela.addActionListener(e -> abrirNovaJanela());

        JMenuItem desconectar = new JMenuItem("Desconectar");
        desconectar.addActionListener(e -> painel.desconectarEVoltar());

        arquivo.add(novaJanela);
        arquivo.add(desconectar);

        JMenuBar barra = new JMenuBar();
        barra.add(arquivo);
        return barra;
    }

    private void abrirNovaJanela() {
        ClienteChatGUI nova = new ClienteChatGUI();
        nova.setLocation(getX() + 40, getY() + 40);
        nova.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // segue com o visual padrao do Java
        }
        SwingUtilities.invokeLater(() -> new ClienteChatGUI().setVisible(true));
    }
}
