package client;

import model.Usuario;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Painel do cliente do chat (Swing): contem as duas telas e toda a logica de conexao.
 *
 * Duas telas (CardLayout): "login" (nome, servidor e porta) e "chat" (mensagens + campo de envio).
 * A leitura do servidor roda numa thread separada; tudo que mexe na tela passa por
 * SwingUtilities.invokeLater, pois componentes Swing so podem ser alterados pela thread de eventos (EDT).
 *
 * A janela (JFrame) fica em {@link ClienteChatGUI}; cada janela tem um painel com a PROPRIA conexao.
 */
@SuppressWarnings({"serial", "this-escape"})
public class ClienteChatPainel extends JPanel {

    private static final String TELA_LOGIN = "login";
    private static final String TELA_CHAT = "chat";
    private static final Font FONTE = new Font("SansSerif", Font.PLAIN, 14);

    private final CardLayout cartas = new CardLayout();
    private final Consumer<String> definirTitulo;

    // ----- tela de login -----
    private final JTextField campoNome = new JTextField(18);
    private final JTextField campoHost = new JTextField("localhost", 18);
    private final JTextField campoPorta = new JTextField("5000", 18);
    private final JButton botaoEntrar = new JButton("Entrar");
    private final JLabel avisoLogin = new JLabel(" ");

    // ----- tela do chat -----
    private final JTextPane areaMensagens = new JTextPane();
    private final JTextField campoMensagem = new JTextField();
    private final JButton botaoEnviar = new JButton("Enviar");
    private final JLabel statusChat = new JLabel(" ");

    private Style estiloNormal;
    private Style estiloMinha;
    private Style estiloSistema;

    // acessados pela thread de leitura e pela EDT
    private volatile Socket socket;
    private volatile PrintWriter saida;
    private volatile Pattern padraoMinhaMensagem;

    /** @param definirTitulo chamado para trocar o titulo da janela (ex.: "Chat - Ana") */
    public ClienteChatPainel(Consumer<String> definirTitulo) {
        this.definirTitulo = definirTitulo;
        setLayout(cartas);

        criarEstilos();
        add(criarTelaLogin(), TELA_LOGIN);
        add(criarTelaChat(), TELA_CHAT);

        botaoEntrar.addActionListener(e -> conectar());
        campoNome.addActionListener(e -> conectar());
        campoHost.addActionListener(e -> conectar());
        campoPorta.addActionListener(e -> conectar());
        botaoEnviar.addActionListener(e -> enviar());
        campoMensagem.addActionListener(e -> enviar());

        cartas.show(this, TELA_LOGIN);
    }

    // =====================================================================
    //  Montagem da interface
    // =====================================================================

    private void criarEstilos() {
        StyledDocument doc = areaMensagens.getStyledDocument();
        estiloNormal = doc.addStyle("normal", null);
        StyleConstants.setFontFamily(estiloNormal, "SansSerif");
        StyleConstants.setFontSize(estiloNormal, 14);

        estiloMinha = doc.addStyle("minha", estiloNormal);
        StyleConstants.setForeground(estiloMinha, new Color(0x1F5FBF));
        StyleConstants.setBold(estiloMinha, true);

        estiloSistema = doc.addStyle("sistema", estiloNormal);
        StyleConstants.setForeground(estiloSistema, new Color(0x777777));
        StyleConstants.setItalic(estiloSistema, true);
    }

    private JPanel criarTelaLogin() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Chat Multiusuário", JLabel.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 26));
        g.gridx = 0;
        g.gridy = 0;
        g.gridwidth = 2;
        g.insets = new Insets(6, 6, 24, 6);
        painel.add(titulo, g);

        g.gridwidth = 1;
        g.insets = new Insets(6, 6, 6, 6);
        adicionarLinha(painel, g, 1, "Seu nome:", campoNome);
        adicionarLinha(painel, g, 2, "Servidor:", campoHost);
        adicionarLinha(painel, g, 3, "Porta:", campoPorta);

        botaoEntrar.setFont(FONTE);
        g.gridx = 0;
        g.gridy = 4;
        g.gridwidth = 2;
        g.insets = new Insets(18, 6, 6, 6);
        painel.add(botaoEntrar, g);

        avisoLogin.setForeground(new Color(0xB00020));
        avisoLogin.setHorizontalAlignment(JLabel.CENTER);
        g.gridy = 5;
        g.insets = new Insets(6, 6, 6, 6);
        painel.add(avisoLogin, g);

        return painel;
    }

    private void adicionarLinha(JPanel painel, GridBagConstraints g, int linha, String rotulo, JTextField campo) {
        JLabel l = new JLabel(rotulo);
        l.setFont(FONTE);
        campo.setFont(FONTE);
        g.gridx = 0;
        g.gridy = linha;
        g.weightx = 0;
        painel.add(l, g);
        g.gridx = 1;
        g.weightx = 1;
        painel.add(campo, g);
    }

    private JPanel criarTelaChat() {
        JPanel painel = new JPanel(new BorderLayout(8, 8));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        statusChat.setFont(new Font("SansSerif", Font.BOLD, 13));
        painel.add(statusChat, BorderLayout.NORTH);

        areaMensagens.setEditable(false);
        areaMensagens.setMargin(new Insets(8, 8, 8, 8));
        painel.add(new JScrollPane(areaMensagens), BorderLayout.CENTER);

        campoMensagem.setFont(FONTE);
        botaoEnviar.setFont(FONTE);
        JPanel rodape = new JPanel(new BorderLayout(8, 0));
        rodape.add(campoMensagem, BorderLayout.CENTER);
        rodape.add(botaoEnviar, BorderLayout.EAST);
        painel.add(rodape, BorderLayout.SOUTH);

        return painel;
    }

    // =====================================================================
    //  Conexao
    // =====================================================================

    private void conectar() {
        if (!botaoEntrar.isEnabled()) {
            return; // ja esta conectando
        }
        String nome = campoNome.getText().trim();
        String host = campoHost.getText().trim();
        int porta;
        try {
            porta = Integer.parseInt(campoPorta.getText().trim());
        } catch (NumberFormatException e) {
            avisoLogin.setText("Porta inválida.");
            return;
        }
        if (!Usuario.nomeValido(nome)) {
            avisoLogin.setText("Nome inválido: use letras, números ou _ (até "
                    + Usuario.TAMANHO_MAXIMO_NOME + "), sem espaços.");
            return;
        }
        if (host.isEmpty()) {
            avisoLogin.setText("Informe o servidor.");
            return;
        }

        botaoEntrar.setEnabled(false);
        avisoLogin.setForeground(new Color(0x555555));
        avisoLogin.setText("Conectando...");

        // O socket e registrado ja aqui: assim "Desconectar" tambem cancela uma conexao em andamento.
        Socket novo = new Socket();
        this.socket = novo;

        // A conexao e a leitura ficam fora da EDT para a janela nao travar.
        new Thread(() -> executarSessao(novo, host, porta, nome), "leitor-servidor").start();
    }

    /** Roda na thread de leitura: conecta, faz o login e fica lendo ate a conexao acabar. */
    private void executarSessao(Socket s, String host, int porta, String nome) {
        boolean registrado = false;
        String motivoErro = null;
        try {
            s.connect(new InetSocketAddress(host, porta), 5000);
            BufferedReader entrada = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter escrita = new PrintWriter(
                    new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);

            this.padraoMinhaMensagem = Pattern.compile(
                    "^\\[\\d{2}:\\d{2}:\\d{2}\\] " + Pattern.quote(nome) + ": .*");
            this.saida = escrita;

            boolean nomeEnviado = false;
            String linha;
            while ((linha = entrada.readLine()) != null) {
                if (!registrado) {
                    if (linha.startsWith("Digite seu nome")) {
                        if (nomeEnviado) {
                            // o servidor pediu o nome de novo: recusou o anterior
                            if (motivoErro == null) {
                                motivoErro = "Nome recusado pelo servidor.";
                            }
                            break;
                        }
                        escrita.println(nome);
                        nomeEnviado = true;
                    } else if (linha.startsWith("Nome invalido") || linha.contains("ja esta em uso")) {
                        motivoErro = linha;
                    } else if (linha.startsWith("Bem-vindo")) {
                        registrado = true;
                        final String hostPorta = host + ":" + porta;
                        SwingUtilities.invokeLater(() -> mostrarChat(nome, hostPorta));
                        exibir(linha);
                    }
                } else {
                    exibir(linha);
                }
            }
        } catch (IOException e) {
            if (!registrado) {
                motivoErro = "Não foi possível conectar em " + host + ":" + porta + ".";
            }
        } finally {
            try {
                s.close();
            } catch (IOException ignorado) {
                // nada a fazer
            }
            final boolean estavaNoChat = registrado;
            final String erro = motivoErro;
            SwingUtilities.invokeLater(() -> aoEncerrarConexao(s, estavaNoChat, erro));
        }
    }

    /** Chamado na EDT quando a leitura termina. Ignora sessoes antigas, ja descartadas pelo usuario. */
    private void aoEncerrarConexao(Socket quemEncerrou, boolean estavaNoChat, String erro) {
        if (socket != quemEncerrou) {
            return; // o usuario desconectou de proposito (ou ja abriu outra sessao): nada a fazer
        }
        socket = null;
        saida = null;
        if (estavaNoChat) {
            voltarParaLogin("A conexão com o servidor foi encerrada.");
        } else {
            voltarParaLogin(erro != null ? erro : "Não foi possível entrar no chat.");
        }
    }

    /** Desconecta (se estiver conectado) e volta para a tela de login. */
    public void desconectarEVoltar() {
        desconectar();
        voltarParaLogin("");
    }

    /** Envia /sair ao servidor e fecha o socket. Usado tambem ao fechar a janela. */
    public void desconectar() {
        PrintWriter p = saida;
        Socket s = socket;
        socket = null;
        saida = null;
        if (p != null) {
            p.println("/sair");
        }
        if (s != null) {
            try {
                s.close();
            } catch (IOException ignorado) {
                // nada a fazer
            }
        }
    }

    // =====================================================================
    //  Telas
    // =====================================================================

    private void mostrarChat(String nome, String hostPorta) {
        areaMensagens.setText("");
        statusChat.setText("Conectado como " + nome + "  -  " + hostPorta);
        definirTitulo.accept("Chat - " + nome);
        cartas.show(this, TELA_CHAT);
        campoMensagem.requestFocusInWindow();
    }

    private void voltarParaLogin(String aviso) {
        botaoEntrar.setEnabled(true);
        avisoLogin.setForeground(new Color(0xB00020));
        avisoLogin.setText(aviso.isEmpty() ? " " : aviso);
        definirTitulo.accept("Chat Multiusuário");
        cartas.show(this, TELA_LOGIN);
        campoNome.requestFocusInWindow();
    }

    // =====================================================================
    //  Mensagens
    // =====================================================================

    private void enviar() {
        String texto = campoMensagem.getText().trim();
        PrintWriter p = saida;
        if (texto.isEmpty() || p == null) {
            return;
        }
        campoMensagem.setText("");
        if (texto.equalsIgnoreCase("/sair")) {
            desconectar();
            voltarParaLogin("");
            return;
        }
        p.println(texto); // o servidor devolve a propria mensagem no broadcast, por isso nao a exibimos aqui
    }

    /** Pode ser chamado de qualquer thread. */
    private void exibir(String linha) {
        SwingUtilities.invokeLater(() -> {
            StyledDocument doc = areaMensagens.getStyledDocument();
            Style estilo = estiloNormal;
            Pattern minha = padraoMinhaMensagem;
            boolean aviso = linha.startsWith("***") || linha.startsWith("---")
                    || linha.startsWith("(") || linha.startsWith("Bem-vindo");
            if (aviso) {
                estilo = estiloSistema;
            } else if (minha != null && minha.matcher(linha).matches()) {
                estilo = estiloMinha;
            }
            try {
                doc.insertString(doc.getLength(), linha + "\n", estilo);
            } catch (BadLocationException e) {
                // posicao sempre valida (fim do documento)
            }
            areaMensagens.setCaretPosition(doc.getLength()); // rola ate a ultima mensagem
        });
    }
}
