package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Cliente de console: uma thread exibe o que chega do servidor,
 * enquanto a thread principal le o teclado e envia.
 */
public class ClienteChat {

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;

        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        try (Socket socket = new Socket(host, porta)) {
            BufferedReader doServidor = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter paraServidor = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
            BufferedReader teclado = new BufferedReader(
                    new InputStreamReader(System.in, StandardCharsets.UTF_8));

            Thread leitor = new Thread(() -> {
                try {
                    String linha;
                    while ((linha = doServidor.readLine()) != null) {
                        System.out.println(linha);
                    }
                } catch (IOException e) {
                    // conexao encerrada
                }
                System.out.println("Conexao encerrada pelo servidor.");
                System.exit(0);
            }, "leitor-servidor");
            leitor.setDaemon(true);
            leitor.start();

            String texto;
            while ((texto = teclado.readLine()) != null) {
                paraServidor.println(texto);
                if (texto.trim().equalsIgnoreCase("/sair")) {
                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Nao foi possivel conectar em " + host + ":" + porta + " -> " + e.getMessage());
        }
    }
}
