package model;

import java.util.Objects;

/**
 * Entidade de dominio: um usuario do chat.
 * Concentra a regra de validacao do nome (sem depender de rede ou banco).
 */
public class Usuario {

    public static final int TAMANHO_MAXIMO_NOME = 20;

    private final String nome;

    public Usuario(String nome) {
        if (!nomeValido(nome)) {
            throw new IllegalArgumentException(
                    "Nome invalido: use de 1 a " + TAMANHO_MAXIMO_NOME
                            + " caracteres (letras, numeros ou _), sem espacos.");
        }
        this.nome = nome.trim();
    }

    /** Regra: 1 a 20 caracteres, apenas letras, digitos ou underscore. */
    public static boolean nomeValido(String nome) {
        if (nome == null) {
            return false;
        }
        String n = nome.trim();
        return !n.isEmpty()
                && n.length() <= TAMANHO_MAXIMO_NOME
                && n.matches("[\\p{L}\\p{N}_]+");
    }

    public String getNome() {
        return nome;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        return nome.equalsIgnoreCase(((Usuario) o).nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome.toLowerCase());
    }

    @Override
    public String toString() {
        return nome;
    }
}
