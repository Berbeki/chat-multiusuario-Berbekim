package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Entidade de dominio: uma mensagem do chat (remetente, conteudo e horario).
 * Imutavel, o que a torna segura para circular entre threads.
 */
public class Mensagem {

    public static final int TAMANHO_MAXIMO_CONTEUDO = 500;

    private static final DateTimeFormatter FORMATO_HORA = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final String remetente;
    private final String conteudo;
    private final LocalDateTime horario;

    /** Cria uma mensagem com o horario atual. */
    public Mensagem(String remetente, String conteudo) {
        this(remetente, conteudo, LocalDateTime.now());
    }

    /** Usado tambem ao reconstruir mensagens vindas do banco. */
    public Mensagem(String remetente, String conteudo, LocalDateTime horario) {
        if (remetente == null || remetente.trim().isEmpty()) {
            throw new IllegalArgumentException("Remetente obrigatorio.");
        }
        if (conteudo == null || conteudo.trim().isEmpty()) {
            throw new IllegalArgumentException("A mensagem nao pode ser vazia.");
        }
        if (conteudo.trim().length() > TAMANHO_MAXIMO_CONTEUDO) {
            throw new IllegalArgumentException(
                    "A mensagem excede " + TAMANHO_MAXIMO_CONTEUDO + " caracteres.");
        }
        if (horario == null) {
            throw new IllegalArgumentException("Horario obrigatorio.");
        }
        this.remetente = remetente.trim();
        this.conteudo = conteudo.trim();
        this.horario = horario;
    }

    /** Texto enviado aos clientes, no formato: [HH:mm:ss] remetente: conteudo */
    public String formatar() {
        return "[" + horario.format(FORMATO_HORA) + "] " + remetente + ": " + conteudo;
    }

    public String getRemetente() {
        return remetente;
    }

    public String getConteudo() {
        return conteudo;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    @Override
    public String toString() {
        return formatar();
    }
}
