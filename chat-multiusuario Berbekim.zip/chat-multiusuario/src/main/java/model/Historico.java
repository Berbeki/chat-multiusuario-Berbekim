package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Regras de negocio do historico, isoladas de banco e rede para poderem ser testadas.
 */
public final class Historico {

    public static final int LIMITE_PADRAO = 20;
    public static final int LIMITE_MAXIMO = 100;

    private Historico() {
    }

    /** Garante que a quantidade pedida fique entre 1 e LIMITE_MAXIMO (invalido vira o padrao). */
    public static int normalizarLimite(int pedido) {
        if (pedido <= 0) {
            return LIMITE_PADRAO;
        }
        return Math.min(pedido, LIMITE_MAXIMO);
    }

    /** Converte a lista de mensagens em linhas de texto prontas para enviar ao cliente. */
    public static List<String> formatar(List<Mensagem> mensagens) {
        List<String> linhas = new ArrayList<>();
        for (Mensagem m : mensagens) {
            linhas.add(m.formatar());
        }
        return linhas;
    }
}
