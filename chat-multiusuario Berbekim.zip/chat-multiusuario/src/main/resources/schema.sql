-- Script de criacao da tabela de mensagens (banco H2)
-- O servidor executa este mesmo comando automaticamente ao iniciar.
CREATE TABLE IF NOT EXISTS mensagens (
    id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    remetente VARCHAR(20)  NOT NULL,
    conteudo  VARCHAR(500) NOT NULL,
    horario   TIMESTAMP    NOT NULL
);
