# Chat Multiusuario com Historico (POO - Java)

Servidor de chat com sockets, uma thread por cliente, broadcast sincronizado
e historico salvo em banco H2 via JDBC.

## Como rodar (IntelliJ IDEA)
1. File > Open... e escolha a pasta do projeto (onde esta o pom.xml). Aguarde o Maven baixar as dependencias.
2. Use JDK 17 ou superior (File > Project Structure > Project SDK).
3. Abra `server/Servidor.java` e clique no triangulo verde ao lado do `main` > Run.
4. **Interface grafica (recomendado):** abra `client/ClienteChatGUI.java` e rode o `main`. Abre a janela de login.
   Em **Arquivo > Nova janela** (Ctrl+N) abra mais janelas: cada uma e um usuario diferente (use 3 para o video).
   Nome sem espacos (letras, numeros ou _). `/sair` ou Arquivo > Desconectar sai do chat.
   **Cliente de console (opcional):** abra `client/ClienteChat.java`, Run uma vez. Depois: Run > Edit Configurations > ClienteChat >
   Modify options > marque "Allow multiple instances". Rode de novo para abrir mais clientes (minimo 3).
5. Digite um nome em cada cliente e converse. `/sair` desconecta.

## Testes
Clique com o botao direito na pasta `src/test/java` > Run 'All Tests' (ou `mvn test`).

## Banco
H2 em arquivo (`./data/chatdb`), criado automaticamente. Script em `src/main/resources/schema.sql`.
Para zerar o historico, pare o servidor e apague a pasta `data`.
